@echo off
title Cleaner 0.1

rem 1) Dossier d'installation = dossier où se trouve ce script
set "APPDIR=%~dp0"
echo %APPDIR%
echo.
rem taskkill /im MonApp.exe /f >nul 2>&1
rem 3) Créer un script temporaire qui fera le nettoyage
set "CLEANUP=%TEMP%\cleanup_monapp_%RANDOM%.bat"

echo @echo off>"%CLEANUP%"
echo echo Cleanup...>>"%CLEANUP%"
echo timeout /t 2 /nobreak ^>nul>>"%CLEANUP%"
rem 4) Supprimer le dossier d'installation
echo rmdir /s /q "%APPDIR%">>"%CLEANUP%"
rem 5) Le script temporaire se supprime lui-même
echo del "%%~f0" ^>nul 2^>^&1>>"%CLEANUP%"

echo.
echo Lancement du nettoyage...
start "" cmd /c "%CLEANUP%"

echo cleaning up.
exit