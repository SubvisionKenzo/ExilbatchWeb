Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# --- Détection de la langue système ---
$Lang = (Get-Culture).Name

switch -Regex ($Lang) {
    "fr" {
        $TXT_Title = "SetupInstaller"
        $TXT_Current = "Version actuelle"
        $TXT_Online = "Version en ligne"
        $TXT_Question = "Voulez-vous installer la version locale ?"
        $TXT_Install = "Installer"
        $TXT_Close = "Fermer"
    }
    "es" {
        $TXT_Title = "Instalador"
        $TXT_Current = "Versión actual"
        $TXT_Online = "Versión en línea"
        $TXT_Question = "¿Desea instalar la versión local?"
        $TXT_Install = "Instalar"
        $TXT_Close = "Cerrar"
    }
    "de" {
        $TXT_Title = "SetupInstaller"
        $TXT_Current = "Aktuelle Version"
        $TXT_Online = "Online-Version"
        $TXT_Question = "Möchten Sie die lokale Version installieren?"
        $TXT_Install = "Installieren"
        $TXT_Close = "Schließen"
    }
    "ru" {
        $TXT_Title = "Установщик"
        $TXT_Current = "Текущая версия"
        $TXT_Online = "Онлайн версия"
        $TXT_Question = "Установить локальную версию?"
        $TXT_Install = "Установить"
        $TXT_Close = "Закрыть"
    }
    default {
        $TXT_Title = "SetupInstaller"
        $TXT_Current = "Current version"
        $TXT_Online = "Online version"
        $TXT_Question = "Do you want to install the local version?"
        $TXT_Install = "Install"
        $TXT_Close = "Close"
    }
}

# --- Détermination du chemin du script ---
if ($MyInvocation.MyCommand.Path) {
    # Exécuté depuis un fichier .ps1
    $BasePath = Split-Path -Parent $MyInvocation.MyCommand.Path
} else {
    # Exécuté dans la console PowerShell
    $BasePath = (Get-Location).Path
}

# --- Lecture des versions ---
$OnlineVersionFile = Join-Path $BasePath "onlineversion.txt"

if (Test-Path $OnlineVersionFile) {
    $OnlineVersion = Get-Content $OnlineVersionFile -Raw
} else {
    $OnlineVersion = "N/A"
}

$CurrentVersion = ""

# --- Création de la fenêtre ---
$form = New-Object System.Windows.Forms.Form
$form.Text = $TXT_Title
$form.Size = New-Object System.Drawing.Size(450, 260)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.BackColor = "#1E1E1E"
$form.TopMost = $true

# --- Icône ---
$icon = [System.Drawing.SystemIcons]::Information
$pic = New-Object System.Windows.Forms.PictureBox
$pic.Image = $icon.ToBitmap()
$pic.SizeMode = "StretchImage"
$pic.Width = 48
$pic.Height = 48
$pic.Left = 20
$pic.Top = 20
$form.Controls.Add($pic)

# --- Texte ---
$msg = New-Object System.Windows.Forms.Label
$msg.Left = 80
$msg.Top = 20
$msg.Width = 330
$msg.Height = 140
$msg.Font = "Segoe UI, 10"
$msg.ForeColor = "White"
$msg.Text = @"
==== $TXT_Title ====
$TXT_Current : $CurrentVersion
$TXT_Online  : $OnlineVersion

$TXT_Question
"@
$form.Controls.Add($msg)

# --- Style bouton violet ---
function New-ModernButton($text, $x, $y) {
    $btn = New-Object System.Windows.Forms.Button
    $btn.Text = $text
    $btn.Width = 130
    $btn.Height = 40
    $btn.Left = $x
    $btn.Top = $y
    $btn.FlatStyle = "Flat"
    $btn.BackColor = "#6A0DAD"
    $btn.ForeColor = "White"
    $btn.Font = "Segoe UI, 10"
    $btn.FlatAppearance.BorderSize = 0
    $btn.Cursor = "Hand"
    return $btn
}

# --- Bouton Installer ---
$btnInstall = New-ModernButton $TXT_Install 70 160
$btnInstall.Add_Click({
    $form.Close()
})
$form.Controls.Add($btnInstall)

# --- Bouton Fermer ---
$btnClose = New-ModernButton $TXT_Close 230 160
$btnClose.Add_Click({
    $hiddenFile = Join-Path $BasePath "close.txt"
    Set-Content -Path $hiddenFile -Value "x" -Encoding UTF8
    $form.Close()
})
$form.Controls.Add($btnClose)

$form.ShowDialog()