@echo off
cd /d "%~dp0"
setlocal enabledelayedexpansion

title ExilBatch Updater
color 0a

if not exist bin mkdir bin

set "onlineversion=online_version"
set "localversion=runtime_version"
set "name=update"
set "urldir=https://raw.githubusercontent.com/SubvisionKenzo/ExilBatch/main/version/"

REM ============================
REM Vérifier internet
REM ============================
ping -n 1 google.com >nul 2>&1
if errorlevel 1 (
    color 0c
    PowerShell -ExecutionPolicy Bypass -File "%name%.ps1" /wait
    timeout 1 > nul
    goto offline
)

REM ============================
REM Vérifier admin
REM ============================
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

REM ============================
REM Lire version locale
REM ============================
for /f "tokens=2 delims=<>" %%A in ('findstr /i "<Version>" %localversion%.xml') do (
    set localVersion=%%A
)

REM ============================
REM Télécharger version en ligne
REM ============================
WebClient.exe /download "%urldir%version.txt" "%onlineversion%.txt"

if not exist "%onlineversion%.txt" (
    echo 0>%onlineversion%.txt
)

set /p onlineVersion=<%onlineversion%.txt

echo LOCAL : %localVersion%
echo ONLINE : %onlineVersion%

REM ============================
REM Si déjà à jour
REM ============================
if "%onlineVersion%"=="%localVersion%" (
    del %onlineversion%.txt
    goto installdir
)

REM ============================
REM Mode mise à jour
REM ============================
echo INFO - Updates are available !
echo Downloading split files...

if exist bintemp rd /s /q bintemp
mkdir bintemp

set COUNT=1

echo Connecting to the servers...
cls

:LOOP
set "FILE=%urldir%runtime_%onlineVersion%.zip.%COUNT%"

echo [Testing existing files] : runtime_%onlineVersion%.zip.%COUNT%

for /f %%X in ('WebClient.exe /exists "!FILE!"') do set EXISTS=%%X

if "!EXISTS!"=="false" (
    echo INFO - No new file found, starting extraction!
    goto MOVEFILES
)

echo Downloading : runtime_%onlineVersion%.zip.%COUNT%
WebClient.exe /download "!FILE!" "bintemp/runtime_%onlineVersion%.zip.%COUNT%"

if not exist "bintemp/runtime_%onlineVersion%.zip.%COUNT%" (
    echo.>"bintemp/runtime_%onlineVersion%.zip.%COUNT%"
)

echo runtime_%onlineVersion%.zip.%COUNT%>>bintemp\extractstat.txt

set /a COUNT+=1
goto LOOP

REM ============================
REM Déplacement dans bin/
REM ============================
:MOVEFILES
echo Moving downloaded parts to .\bin ...

if not exist bin mkdir bin

for /f %%F in (bintemp\extractstat.txt) do (
    move /Y "bintemp\%%F" "bin\%%F" >nul
)

rd /s /q bintemp

REM ============================
REM Extraction fichier par fichier
REM ============================
echo Preparing extraction...

set /a TOTAL=0
for /f %%F in ('dir /b bin\runtime_%onlineVersion%.zip.*') do (
    set /a TOTAL+=1
)

echo Total files detected : %TOTAL%
echo.

set /a CURRENT=0

for /f %%F in ('dir /b bin\runtime_%onlineVersion%.zip.*') do (
    set /a CURRENT+=1
    echo [EXTRACT] File %CURRENT%/%TOTAL% : %%F

    7z.exe x "bin\%%F" -obin >nul
    del "bin\%%F"
)

echo.
echo Extraction completed successfully!
echo.

goto installdir

REM ============================
REM Installation
REM ============================
:installdir
echo Starting up installation...
cd "bin/ExilBatch"
start setup.bat
exit

REM ============================
REM Mode hors-ligne
REM ============================
:offline
7z.exe x localinstall.zip -olocalbin
cd "localbin"
start setup.bat
exit