@echo off
cd /d "%~dp0"
cd installer
start download.bat > nul
exit > nul